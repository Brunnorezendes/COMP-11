#include "hash.h"

// LOOK FOR THE COMMENTS IN THE .H 
// TO UNDERSTAND WHAT EACH FUNCTION MUST DO

Hash::Hash(int tablesize, int (*hf) (std::string) ) {
 // CONSTRUTOR 
}

int Hash::add(std::string str, int &collisions) { 
    
    // porque existe 'return 0' neste codigo? 
    // para executar os testes, mesmo falhando, eh preciso compilar
    // assim, eh preciso retornar algum valor.
    // ** o aluno deve implementar a funcao completa e retornar o valor correto **
    return 0;
    
}//add

int Hash::remove(std::string str, int &collisions) { 
    
    
    return 0;
    
}//remove


int Hash::hash(std::string str) { 
    
    return 0;
    
}//hash
    
int Hash::contains(std::string str, int &collisions) { 
    
        
    return 0;
    
}//contains


int Hash::worst_case() {

    return 0;
    
}//worst_case

int Hash::size() {

    return 0;
    
}//size

