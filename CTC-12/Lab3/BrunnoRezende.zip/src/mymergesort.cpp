
#include <mysortfunctions.h>

void merge(std::vector<int> &v, std::vector<int> &n_v, int l, int m, int r){
    int med = m, il=l, ir, k=l;
    ir = med+1;
    
    while(il<=med && ir<=r){
        if(v[il]>v[ir]) n_v[k++] = v[ir++];
        else n_v[k++] = v[il++];
    }
    while(il<=med) n_v[k++] = v[il++];
    while(ir<=r) n_v[k++] = v[ir++];

    for(int i = l; i <= r; i++) v[i] = n_v[i];
}

void mergesort(std::vector<int> &v, SortStats &stats, int l, int r, std::vector<int> &n_v){
    if (l >= r) return;
    int med = (l+r)/2;

    stats.recursive_calls++;
    stats.custom1++;
    stats.depth_recursion_stack = std::max(stats.depth_recursion_stack, stats.custom1);
    
    if(med>l) mergesort(v, stats, l, med, n_v);
    if(med+1<r) mergesort(v, stats, med+1, r, n_v);
    
    merge(v, n_v, l, med, r);
    
    stats.custom1--;
}

void mymergesort_recursive(std::vector<int> &v, SortStats &stats) {
    // you need to set the counting of recursive recursive_calls
    stats.recursive_calls = 0;
    // you need to set the depth = the maximum height of the tree of recursion calls. 
    stats.depth_recursion_stack = 0;
    // the tester already knows the size of v and the algorithm name, it already measures time
    // you may set custom1 field if you want to measure anything else.
    stats.custom1 = 0;
    std::vector<int> n_v(v.size()+10, 0);
    mergesort(v, stats, 0, v.size()-1, n_v);
    
}

void mymergesort_iterative(std::vector<int> &v, SortStats &stats) {
    // you need to set the counting of recursive recursive_calls
    stats.recursive_calls = 1;
    // you need to set the depth = the maximum height of the tree of recursion calls. 
    stats.depth_recursion_stack = 1;
    // the tester already knows the size of v and the algorithm name, it already measures time
    // you may set custom1 field if you want to measure anything else.
    stats.custom1 = 2;

    int m, r;
    std::vector<int> n_v(v.size(), 0);
    for(int i=1;i<v.size();i<<=1){
        for(int j=0;j+i<v.size();j+=2*i){
            m = j + i - 1;
            r = std::min(j + 2 * i - 1, (int)v.size() - 1);
            merge(v, n_v, j, m, r);
        }
    }

}
    
