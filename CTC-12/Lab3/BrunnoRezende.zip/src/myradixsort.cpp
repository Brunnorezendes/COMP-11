
#include <mysortfunctions.h>


void myradixsort(std::vector<int> &v, SortStats &stats) {
    // you need to set the counting of recursive recursive_calls
    stats.recursive_calls = 1;
    // you need to set the depth = the maximum height of the tree of recursion calls. 
    stats.depth_recursion_stack = 1;
    // the tester already knows the size of v and the algorithm name, it already measures time
    // you may set custom1 field if you want to measure anything else.
    stats.custom1 = 2;

    int Bucket_log = 4, Bucket_number, k, actual, u;
    Bucket_number = (1<<Bucket_log);

    std::vector<int> bucket[Bucket_number], idx(Bucket_number, 0);

    for(int i=0;i<Bucket_number;i++) bucket[i] = std::vector<int>(v.size());
    
    for(int i=Bucket_number-1, u=0;(i<v.size())||(i&v.size());i<<=Bucket_log, u++){
        idx = std::vector<int> (Bucket_number, 0);
        for(int j=0;j<v.size();j++){
            actual = (i&v[j])>>(Bucket_log*u);
            bucket[actual][idx[actual]++] = v[j];
        }
        k = 0;
        for(int j=0;j<Bucket_number;j++)
            for(int w=0;w<idx[j];w++) v[k++] = bucket[j][w];
    }
}
