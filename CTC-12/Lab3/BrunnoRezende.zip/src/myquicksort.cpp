
#include <mysortfunctions.h>

// you only need to mantain the headers. You can create aux funcs, objects, or create a generic quicksort that can work with different functions to select the pivot.

int Partition(std::vector<int> &v, int l, int r){
    int il = l+1, ir = r, piv = v[l];
    while(1){
        while(il < r && v[il]<piv) il++;
        while(ir > l && v[ir]>=piv) ir--;
        if(il>=ir) break;
        std::swap(v[il], v[ir]);
    }
    std::swap(v[l], v[ir]);
    return ir;
}

void get_median(std::vector<int> &v, int l, int r){ // this funcion puts the median between first, medium and last element on the first position
    int med = (l+r)/2;
    if(v[l]>v[r]) std::swap(v[l], v[r]);
    if(v[l]<v[med]) std::swap(v[med], v[l]);
    if(v[l]>v[r]) std::swap(v[l], v[r]);
}

void quicksort_2recursion(std::vector<int> &v, SortStats &stats, int l, int r){

    stats.recursive_calls++;
    stats.custom1++;
    stats.depth_recursion_stack = std::max(stats.depth_recursion_stack, stats.custom1);
    int p;
    
    if(l<r){
        get_median(v, l, r);
        p = Partition(v, l, r);
        quicksort_2recursion(v, stats, l, p-1);
        quicksort_2recursion(v, stats, p+1, r);
    }

    stats.custom1--;

}

/// the most comon quicksort, with 2 recursive calls
void myquicksort_2recursion_medianOf3(std::vector<int> &v, SortStats &stats) {
    // you need to set the counting of recursive recursive_calls
    stats.recursive_calls = 0;
    // you need to set the depth = the maximum height of the tree of recursion calls. 
    stats.depth_recursion_stack = 0;
    // the tester already knows the size of v and the algorithm name, it already measures time
    // you may set custom1 field if you want to measure anything else.
    stats.custom1 = 0;

    quicksort_2recursion(v, stats, 0, v.size()-1);
}// function myquicksort_2recursion_medianOf3

void quicksort_1recursion(std::vector<int> &v, SortStats &stats, int l, int r){

    stats.recursive_calls++;
    stats.custom1++;
    stats.depth_recursion_stack = std::max(stats.depth_recursion_stack, stats.custom1);
    int p;
    
    while(l<r){
        get_median(v, l, r);
        p = Partition(v, l, r);
        if(p-l<r-p){
            quicksort_1recursion(v, stats, l, p-1);
            l = p+1;
        }
        else{
            quicksort_1recursion(v, stats, p+1, r);
            r = p-1;
        }
    }

    stats.custom1--;

}

/// quicksort with one recursive call
void myquicksort_1recursion_medianOf3(std::vector<int> &v, SortStats &stats) {
    // you need to set the counting of recursive recursive_calls
    stats.recursive_calls = 0;
    // you need to set the depth = the maximum height of the tree of recursion calls. 
    stats.depth_recursion_stack = 0;
    // the tester already knows the size of v and the algorithm name, it already measures time
    // you may set custom1 field if you want to measure anything else.
    stats.custom1 = 0;

    quicksort_1recursion(v, stats, 0, v.size()-1);
} // function myquicksort_1recursion_medianOf3


void quicksort_fixedPivot(std::vector<int> &v, SortStats &stats, int l, int r){

    stats.recursive_calls++;
    stats.custom1++;
    stats.depth_recursion_stack = std::max(stats.depth_recursion_stack, stats.custom1);
    int p;
    
    if(l<r){
        p = Partition(v, l, r);
        quicksort_fixedPivot(v, stats, l, p-1);
        quicksort_fixedPivot(v, stats, p+1, r);
    }

    stats.custom1--;

}

/// quicksort with fixed pivot 
/// be sure to compare with equivalent implementation 
/// e.g., if you do 1 recursive call, compare with the 1recursion version
void myquicksort_fixedPivot(std::vector<int> &v, SortStats &stats) {
    // you need to set the counting of recursive recursive_calls
    stats.recursive_calls = 0;
    // you need to set the depth = the maximum height of the tree of recursion calls. 
    stats.depth_recursion_stack = 0;
    // the tester already knows the size of v and the algorithm name, it already measures time
    // you may set custom1 field if you want to measure anything else.
    stats.custom1 = 0;

    quicksort_fixedPivot(v, stats, 0, v.size()-1);
} // myquicksort_fixedPivot


