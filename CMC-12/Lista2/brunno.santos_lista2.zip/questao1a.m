function tau = questao1a()
% Retorne a constante de tempo do circuito RLC. Use SI.

% tau = ...
tau = 100;

end