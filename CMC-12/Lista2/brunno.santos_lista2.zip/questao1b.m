function q = questao1b()
% Retorne o valor da carga do capacitor no tempo t = 0.02 s. Use SI.

% q = ...
q = 4.3233235838 .* 10^(-6);

end